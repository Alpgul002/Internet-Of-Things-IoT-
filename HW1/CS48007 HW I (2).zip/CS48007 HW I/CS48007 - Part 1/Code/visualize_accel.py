import csv
import math
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def read_csv_smart(path):
    """Read accelerometer data from CSV, handling different header formats."""
    t, x, y, z = [], [], [], []

    with open(path, "r", newline="") as f:
        rd = csv.DictReader(f)
        for row in rd:
            try:
                tt = float(row.get("seconds_elapsed") or row.get("time"))

                if "x" in row and "y" in row and "z" in row:
                    xx = float(row["x"])
                    yy = float(row["y"])
                    zz = float(row["z"])
                else:
                    # Fallback for legacy format
                    vals = [float(v) for v in list(row.values())[-3:]]
                    xx, yy, zz = vals[0], vals[1], vals[2]

                t.append(tt)
                x.append(xx)
                y.append(yy)
                z.append(zz)

            except (ValueError, TypeError):
                continue

    # Start time at zero
    if t:
        t0 = t[0]
        t = [ti - t0 for ti in t]

    return t, x, y, z


def magnitude(xs, ys, zs):
    """Calculate acceleration magnitude: sqrt(x² + y² + z²)"""
    return [math.sqrt(a*a + b*b + c*c) for a, b, c in zip(xs, ys, zs)]


def main():
    SCRIPT_DIR = Path(__file__).resolve().parent
    BASE_DIR = SCRIPT_DIR.parent
    
    input_file_path = BASE_DIR / "Data" / "AccelerometerUncalibrated.csv"
    output_file_path = BASE_DIR / "accel_plot.png"
    
    print(f"Reading data from: {input_file_path}")
    t, ax, ay, az = read_csv_smart(input_file_path)
    
    if not t:
        print(f"Error: No data read from {input_file_path}. Check file path and format.")
        print("Please make sure your folder structure is: CS48007 - Part 1 / [code, Data]")
        return
    
    mag = magnitude(ax, ay, az)

    plt.figure(figsize=(10, 6))

    # Plot individual axes
    plt.subplot(2, 1, 1)
    plt.plot(t, ax, label="Ax", linewidth=0.8)
    plt.plot(t, ay, label="Ay", linewidth=0.8)
    plt.plot(t, az, label="Az", linewidth=0.8)
    plt.xlabel("Time (s)")
    plt.ylabel("Acceleration (m/s²)")
    plt.title("Accelerometer Axes (with Gravity)")
    plt.legend(loc="upper right")

    # Plot magnitude
    plt.subplot(2, 1, 2)
    plt.plot(t, mag, color="black", label="|a| (Total Magnitude)", linewidth=0.9)
    plt.axhline(9.81, linestyle="--", color="gray", linewidth=1, label="~g (gravity)")
    plt.xlabel("Time (s)")
    plt.ylabel("|a| (m/s²)")
    plt.title("Acceleration Magnitude Over Time")
    plt.legend(loc="upper right")

    plt.tight_layout()
    plt.savefig(output_file_path, dpi=160)
    print(f"✅ Plot saved as: {output_file_path}")


if __name__ == "__main__":
    main()
