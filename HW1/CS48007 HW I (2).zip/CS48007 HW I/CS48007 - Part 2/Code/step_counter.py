import csv
import math
import sys
from typing import List, Dict, Tuple
from pathlib import Path


def read_accel_csv(filename: str) -> List[Dict[str, float]]:
    """Read accelerometer CSV, handling various header formats."""
    data: List[Dict[str, float]] = []

    with open(filename, "r", newline="") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            return data

        cols = [c.strip().lower() for c in rdr.fieldnames]

        # Find time column
        tcol = None
        for cand in ("seconds_elapsed", "elapsed", "time_s"):
            if cand in cols:
                tcol = cand
                break
        if tcol is None:
            tcol = "time" if "time" in cols else rdr.fieldnames[0].strip().lower()

        # Find axis columns
        xcol = "x" if "x" in cols else ("ax" if "ax" in cols else None)
        ycol = "y" if "y" in cols else ("ay" if "ay" in cols else None)
        zcol = "z" if "z" in cols else ("az" if "az" in cols else None)

        if (xcol is None or ycol is None or zcol is None) and all(c in cols for c in ("z", "y", "x")):
            zcol, ycol, xcol = "z", "y", "x"

        raw_times: List[float] = []
        raw_rows: List[Tuple[float, float, float, float]] = []
        for row in rdr:
            try:
                t = float(row[tcol])
                x = float(row[xcol]) if xcol in row and row[xcol] != "" else float(row["x"])
                y = float(row[ycol]) if ycol in row and row[ycol] != "" else float(row["y"])
                z = float(row[zcol]) if zcol in row and row[zcol] != "" else float(row["z"])
                raw_times.append(t)
                raw_rows.append((t, x, y, z))
            except Exception:
                continue

    if not raw_rows:
        return data

    # Start time at zero
    t0 = raw_times[0]
    for t, x, y, z in raw_rows:
        data.append({"t": t - t0, "x": x, "y": y, "z": z})

    return data


def remove_gravity_lowpass(accel: List[Dict[str, float]], alpha: float = 0.85) -> List[Dict[str, float]]:
    """
    Remove gravity using exponential moving average (EMA) low-pass filter.
    g[n] = alpha * g[n-1] + (1 - alpha) * a[n]
    """
    if not accel:
        return []

    g_x, g_y, g_z = accel[0]["x"], accel[0]["y"], accel[0]["z"]
    out: List[Dict[str, float]] = []

    for r in accel:
        ax, ay, az = r["x"], r["y"], r["z"]

        g_x = alpha * g_x + (1.0 - alpha) * ax
        g_y = alpha * g_y + (1.0 - alpha) * ay
        g_z = alpha * g_z + (1.0 - alpha) * az

        out.append({"t": r["t"], "x": ax - g_x, "y": ay - g_y, "z": az - g_z})

    return out


def magnitude_series(accel: List[Dict[str, float]]) -> List[Tuple[float, float]]:
    """Compute magnitude |a| = sqrt(x² + y² + z²) at each time."""
    out: List[Tuple[float, float]] = []
    for r in accel:
        m = math.sqrt(r["x"] * r["x"] + r["y"] * r["y"] + r["z"] * r["z"])
        out.append((r["t"], m))
    return out


def moving_average(signal: List[Tuple[float, float]], samples: int) -> List[Tuple[float, float]]:
    """Smooth signal with simple moving average of N samples."""
    if samples <= 1 or len(signal) <= 2:
        return signal[:]

    buf: List[float] = []
    ssum = 0.0
    out: List[Tuple[float, float]] = []

    for t, v in signal:
        buf.append(v)
        ssum += v
        if len(buf) > samples:
            ssum -= buf.pop(0)
        out.append((t, ssum / len(buf)))

    return out


def detect_peaks_localmax(signal: List[Tuple[float, float]],
                          threshold: float,
                          min_dist_samples: int) -> List[Tuple[int, float, float]]:
    """
    Detect peaks as local maxima above threshold with minimum spacing.
    Peak at i counted if: value[i] > threshold, value[i] is local max,
    and spacing from last peak >= min_dist_samples.
    """
    peaks: List[Tuple[int, float, float]] = []
    last_idx = -min_dist_samples

    for i in range(1, len(signal) - 1):
        t, v = signal[i]
        v_prev = signal[i - 1][1]
        v_next = signal[i + 1][1]

        if v > threshold and v > v_prev and v > v_next and (i - last_idx) >= min_dist_samples:
            peaks.append((i, t, v))
            last_idx = i

    return peaks


def sampling_rate(data: List[Dict[str, float]]) -> float:
    """Estimate average sampling rate from timestamps."""
    if len(data) < 2:
        return 50.0
    duration = data[-1]["t"] - data[0]["t"]
    return (len(data) / duration) if duration > 0 else 50.0


def process_window(window: List[Dict[str, float]],
                   fs: float,
                   alpha: float,
                   ma_secs: float,
                   threshold: float,
                   auto_k: float,
                   min_gap_s: float) -> Tuple[int, List[Tuple[int, float, float]]]:
    """
    Process a single window: remove gravity, compute magnitude, smooth,
    detect peaks. Uses adaptive threshold if threshold <= 0.
    """
    if len(window) < 10:
        return 0, []

    lin = remove_gravity_lowpass(window, alpha=alpha)
    mag = magnitude_series(lin)
    
    ma_samples = max(3, int(fs * ma_secs))
    smo = moving_average(mag, ma_samples)

    # Adaptive threshold or fixed
    if threshold > 0.0:
        thr = threshold
    else:
        vals = [v for _, v in smo]
        mu = sum(vals) / len(vals)
        var = sum((v - mu) * (v - mu) for v in vals) / len(vals)
        sd = math.sqrt(max(var, 0.0))
        thr = mu + auto_k * sd

    min_gap_samples = max(1, int(fs * min_gap_s))
    peaks = detect_peaks_localmax(smo, thr, min_gap_samples)

    return len(peaks), peaks


def count_steps(filename: str,
                output_save_path: Path,
                window_s: float = 10.0,
                alpha: float = 0.85,
                ma_secs: float = 0.05,
                min_gap_s: float = 0.25,
                threshold: float = 0.0,
                auto_k: float = 0.9) -> Tuple[int, List[Dict]]:
    """Count steps over entire file by processing in fixed-size windows."""
    data = read_accel_csv(filename)
    if not data:
        print("No data read.")
        return 0, []

    fs = sampling_rate(data)
    start_t = data[0]["t"]
    end_t = data[-1]["t"]

    total_steps = 0
    results: List[Dict] = []
    steps_all: List[float] = []

    w_start = start_t
    w_idx = 1
    while w_start < end_t:
        w_end = w_start + window_s
        window = [r for r in data if w_start <= r["t"] < w_end]

        if window:
            n_steps, peaks = process_window(
                window, fs, alpha, ma_secs, threshold, auto_k, min_gap_s
            )
            total_steps += n_steps
            steps_all.extend([p[1] for p in peaks])

            results.append({
                "window": w_idx,
                "start": w_start,
                "end": min(w_end, end_t),
                "steps": n_steps
            })
            print(f"Window {w_idx}: {w_start:.1f}s–{min(w_end, end_t):.1f}s  |  Steps: {n_steps}")

        w_start = w_end
        w_idx += 1

    # Save step timestamps
    with open(output_save_path, "w", newline="") as wf:
        w = csv.writer(wf)
        w.writerow(["step_time_seconds_from_start"])
        for st in steps_all:
            w.writerow([f"{st:.3f}"])

    print("-" * 60)
    print(f"Duration: {end_t - start_t:.2f} s   Samples: {len(data)}   fs ≈ {fs:.2f} Hz")
    print(f"Total Steps: {total_steps}")
    print(f"Saved: {output_save_path}")

    return total_steps, results


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 step_counter.py <Accelerometer*.csv> [--thr 1.1]")
        sys.exit(1)

    filename = sys.argv[1]
    SCRIPT_DIR = Path(__file__).resolve().parent
    BASE_DIR = SCRIPT_DIR.parent
    
    full_data_path = BASE_DIR / "Data" / filename
    output_csv_path = BASE_DIR / "steps.csv"
    
    window_s   = 10.0
    alpha      = 0.85
    ma_secs    = 0.05
    min_gap_s  = 0.22

    thr = 0.0
    auto_k = 0.9

    if "--thr" in sys.argv:
        try:
            i = sys.argv.index("--thr")
            thr = float(sys.argv[i + 1])
        except Exception:
            print("Invalid --thr value; using auto threshold.")

    print("=" * 60)
    print("STEP COUNTER (windowed, EMA gravity, MA smoothing, manual peaks)")
    print("=" * 60)
    print(f"File: {filename}")
    print(f"Params: window={window_s}s, alpha={alpha}, ma={ma_secs}s, "
          f"min_gap={min_gap_s}s, threshold={'AUTO' if thr <= 0 else thr} (auto_k={auto_k})")
    print("-" * 60)

    total, _ = count_steps(
        filename=full_data_path,
        output_save_path=output_csv_path,
        window_s=window_s,
        alpha=alpha,
        ma_secs=ma_secs,
        min_gap_s=min_gap_s,
        threshold=thr,
        auto_k=auto_k
    )

    print("\nSUMMARY")
    print("-" * 60)
    print(f"Total Steps: {total}")


if __name__ == "__main__":
    main()
