import csv
import math
import sys
from pathlib import Path

class PoseEstimator:
    """Estimates device orientation using complementary filter for sensor fusion."""
    
    def __init__(self, alpha=0.98):
        """
        Initialize estimator.
        alpha: filter coefficient (0.95-0.99 typical)
               higher = trust gyro more, lower = trust accel more
        """
        self.alpha = alpha
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        self.prev_time = None
    
    def read_csv_file(self, filename):
        """Read CSV and return list of sensor data dictionaries."""
        data = []
        try:
            with open(filename, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    data.append({
                        'time': row['time'],
                        'seconds_elapsed': float(row['seconds_elapsed']),
                        'x': float(row['x']),
                        'y': float(row['y']),
                        'z': float(row['z'])
                    })
        except FileNotFoundError:
            print(f"Error: File '{filename}' not found!")
            sys.exit(1)
        except Exception as e:
            print(f"Error reading file '{filename}': {e}")
            sys.exit(1)
        
        return data
    
    def calculate_roll_pitch_from_accel(self, ax, ay, az):
        """Calculate roll and pitch from accelerometer (gravity vector)."""
        roll = math.atan2(ay, az) * 180.0 / math.pi
        pitch = math.atan2(-ax, math.sqrt(ay * ay + az * az)) * 180.0 / math.pi
        return roll, pitch
    
    def integrate_gyroscope(self, gx, gy, gz, dt):
        """Integrate gyro angular velocities to get angle changes."""
        roll_increment = gx * dt * 180.0 / math.pi
        pitch_increment = gy * dt * 180.0 / math.pi
        yaw_increment = gz * dt * 180.0 / math.pi
        return roll_increment, pitch_increment, yaw_increment
    
    def complementary_filter(self, accel_angle, gyro_angle_increment, current_angle):
        """
        Fuse accelerometer and gyroscope data.
        filtered = alpha * (current + gyro) + (1 - alpha) * accel
        """
        predicted_angle = current_angle + gyro_angle_increment
        filtered_angle = self.alpha * predicted_angle + (1.0 - self.alpha) * accel_angle
        return filtered_angle
    
    def update(self, accel_data, gyro_data):
        """Update pose with new sensor readings."""
        ax, ay, az = accel_data['x'], accel_data['y'], accel_data['z']
        gx, gy, gz = gyro_data['x'], gyro_data['y'], gyro_data['z']
        current_time = accel_data['seconds_elapsed']
        
        if self.prev_time is None:
            dt = 0.0
            self.prev_time = current_time
        else:
            dt = current_time - self.prev_time
            self.prev_time = current_time
        
        accel_roll, accel_pitch = self.calculate_roll_pitch_from_accel(ax, ay, az)
        
        # Initialize on first iteration
        if dt == 0.0:
            self.roll = accel_roll
            self.pitch = accel_pitch
            self.yaw = 0.0
            return
        
        roll_increment, pitch_increment, yaw_increment = self.integrate_gyroscope(gx, gy, gz, dt)
        
        self.roll = self.complementary_filter(accel_roll, roll_increment, self.roll)
        self.pitch = self.complementary_filter(accel_pitch, pitch_increment, self.pitch)
        
        # Yaw only has gyro (no magnetometer), will drift
        self.yaw = self.yaw + yaw_increment
        
        # Keep yaw in [-180, 180]
        while self.yaw > 180.0:
            self.yaw -= 360.0
        while self.yaw < -180.0:
            self.yaw += 360.0
    
    def get_orientation(self):
        """Return current orientation angles."""
        return {
            'roll': self.roll,
            'pitch': self.pitch,
            'yaw': self.yaw
        }


def synchronize_sensor_data(accel_data, gyro_data, tolerance=0.01):
    """
    Match accelerometer and gyroscope samples by timestamp.
    tolerance: max time difference in seconds to consider a match
    """
    synchronized = []
    
    for accel_sample in accel_data:
        accel_time = accel_sample['seconds_elapsed']
        
        closest_gyro = None
        min_diff = float('inf')
        
        for gyro_sample in gyro_data:
            gyro_time = gyro_sample['seconds_elapsed']
            time_diff = abs(accel_time - gyro_time)
            
            if time_diff < min_diff:
                min_diff = time_diff
                closest_gyro = gyro_sample
        
        if closest_gyro and min_diff <= tolerance:
            synchronized.append((accel_sample, closest_gyro))
    
    return synchronized


def calculate_statistics(values):
    """Calculate basic stats: mean, min, max, std."""
    if not values:
        return {'mean': 0, 'min': 0, 'max': 0, 'std': 0}
    
    n = len(values)
    mean = sum(values) / n
    min_val = min(values)
    max_val = max(values)
    
    variance = sum((x - mean) ** 2 for x in values) / n
    std = math.sqrt(variance)
    
    return {
        'mean': mean,
        'min': min_val,
        'max': max_val,
        'std': std
    }


def save_results(timestamps, roll_angles, pitch_angles, yaw_angles, output_file='pose_estimation_results.csv'):
    """Save pose estimation results to CSV."""
    try:
        with open(output_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['seconds_elapsed', 'roll_deg', 'pitch_deg', 'yaw_deg'])
            
            for t, r, p, y in zip(timestamps, roll_angles, pitch_angles, yaw_angles):
                writer.writerow([f'{t:.6f}', f'{r:.2f}', f'{p:.2f}', f'{y:.2f}'])
        
        print(f"\nResults saved to: {output_file}")
    except Exception as e:
        print(f"Error saving results: {e}")


def main():
    print("=" * 70)
    print("POSE ESTIMATION FROM ACCELEROMETER AND GYROSCOPE DATA")
    print("=" * 70)
    print()
    
    SCRIPT_DIR = Path(__file__).resolve().parent
    BASE_DIR = SCRIPT_DIR.parent
    
    accel_file = BASE_DIR / "Data" / 'AccelerometerUncalibrated.csv'
    gyro_file = BASE_DIR / "Data" / 'GyroscopeUncalibrated.csv'
    output_csv_path = BASE_DIR / 'pose_estimation_results.csv'
    output_plot_path = BASE_DIR / 'pose_estimation_plot.png'
    
    # Alpha = 0.98 means 98% gyro, 2% accel
    estimator = PoseEstimator(alpha=0.98)
    
    print("Step 1: Reading sensor data files...")
    accel_data = estimator.read_csv_file(accel_file)
    gyro_data = estimator.read_csv_file(gyro_file)
    print(f"  - Accelerometer samples: {len(accel_data)}")
    print(f"  - Gyroscope samples: {len(gyro_data)}")
    
    print("\nStep 2: Synchronizing sensor data...")
    synchronized_data = synchronize_sensor_data(accel_data, gyro_data)
    print(f"  - Synchronized samples: {len(synchronized_data)}")
    
    if len(synchronized_data) == 0:
        print("\nError: No synchronized samples found!")
        print("Check that both CSV files have overlapping timestamps.")
        sys.exit(1)
    
    print("\nStep 3: Processing sensor data with complementary filter...")
    
    timestamps = []
    roll_angles = []
    pitch_angles = []
    yaw_angles = []
    
    for accel_sample, gyro_sample in synchronized_data:
        estimator.update(accel_sample, gyro_sample)
        orientation = estimator.get_orientation()
        
        timestamps.append(accel_sample['seconds_elapsed'])
        roll_angles.append(orientation['roll'])
        pitch_angles.append(orientation['pitch'])
        yaw_angles.append(orientation['yaw'])
    
    print(f"  - Processed {len(timestamps)} samples successfully")
    
    print("\nStep 4: Calculating statistics...")
    
    roll_stats = calculate_statistics(roll_angles)
    pitch_stats = calculate_statistics(pitch_angles)
    yaw_stats = calculate_statistics(yaw_angles)
    
    print("\n" + "=" * 70)
    print("ORIENTATION STATISTICS (degrees)")
    print("=" * 70)
    
    print("\nROLL (rotation around X-axis):")
    print(f"  Mean:  {roll_stats['mean']:8.2f}°")
    print(f"  Std:   {roll_stats['std']:8.2f}°")
    print(f"  Range: [{roll_stats['min']:8.2f}°, {roll_stats['max']:8.2f}°]")
    
    print("\nPITCH (rotation around Y-axis):")
    print(f"  Mean:  {pitch_stats['mean']:8.2f}°")
    print(f"  Std:   {pitch_stats['std']:8.2f}°")
    print(f"  Range: [{pitch_stats['min']:8.2f}°, {pitch_stats['max']:8.2f}°]")
    
    print("\nYAW (rotation around Z-axis):")
    print(f"  Mean:  {yaw_stats['mean']:8.2f}°")
    print(f"  Std:   {yaw_stats['std']:8.2f}°")
    print(f"  Range: [{yaw_stats['min']:8.2f}°, {yaw_stats['max']:8.2f}°]")
    
    print("\n" + "=" * 70)
    
    save_results(timestamps, roll_angles, pitch_angles, yaw_angles, output_file=output_csv_path)
    
    # Create visualization if matplotlib available
    try:
        import matplotlib.pyplot as plt
        
        try:
            plt.switch_backend('Agg')
            print("\nUsing 'Agg' backend for matplotlib")
        except Exception:
            print("\nCould not switch matplotlib backend, continuing...")

        print("\nGenerating visualization...")
        
        fig, axes = plt.subplots(3, 1, figsize=(12, 10))
        fig.suptitle('Pose Estimation Results - Complementary Filter', fontsize=14, fontweight='bold')
        
        axes[0].plot(timestamps, roll_angles, 'b-', linewidth=1.5, label='Roll')
        axes[0].axhline(y=roll_stats['mean'], color='r', linestyle='--', alpha=0.7, label=f'Mean: {roll_stats["mean"]:.1f}°')
        axes[0].set_ylabel('Roll (degrees)', fontsize=11)
        axes[0].grid(True, alpha=0.3)
        axes[0].legend(loc='upper right')
        axes[0].set_title('Roll - Rotation around X-axis (left/right tilt)')
        
        axes[1].plot(timestamps, pitch_angles, 'g-', linewidth=1.5, label='Pitch')
        axes[1].axhline(y=pitch_stats['mean'], color='r', linestyle='--', alpha=0.7, label=f'Mean: {pitch_stats["mean"]:.1f}°')
        axes[1].set_ylabel('Pitch (degrees)', fontsize=11)
        axes[1].grid(True, alpha=0.3)
        axes[1].legend(loc='upper right')
        axes[1].set_title('Pitch - Rotation around Y-axis (forward/backward tilt)')
        
        axes[2].plot(timestamps, yaw_angles, 'm-', linewidth=1.5, label='Yaw (drifts)')
        axes[2].axhline(y=yaw_stats['mean'], color='r', linestyle='--', alpha=0.7, label=f'Mean: {yaw_stats["mean"]:.1f}°')
        axes[2].set_xlabel('Time (seconds)', fontsize=11)
        axes[2].set_ylabel('Yaw (degrees)', fontsize=11)
        axes[2].grid(True, alpha=0.3)
        axes[2].legend(loc='upper right')
        axes[2].set_title('Yaw - Rotation around Z-axis (heading, no magnetometer correction)')
        
        plt.tight_layout()
        plt.savefig(output_plot_path, dpi=150, bbox_inches='tight')
        print(f"  - Plot saved to: {output_plot_path}")
        
    except ImportError:
        print("\nNote: matplotlib not available. Skipping visualization.")
        print("      Install matplotlib for visual plots: pip3 install matplotlib")
    
    print("\nPose estimation complete")


if __name__ == '__main__':
    main()
