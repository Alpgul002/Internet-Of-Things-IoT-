import subprocess
import re
import pandas as pd
import time
import sys
from datetime import datetime

# to get wifi info
def scan_wifi():
    try:
        result = subprocess.check_output(["netsh", "wlan", "show", "networks", "mode=bssid"], shell=True)
        txt = result.decode('utf-8', errors='ignore')
        return txt
    except:
        return None

# this function parses the netsh output and extracts bssid + signal
def parse_it(raw_text, room_name):
    
    networks = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # split by ssid first
    parts = re.split(r'\nSSID \d+\s+:', raw_text)
    parts = parts[1:] # first one is junk
    
    for p in parts:
        try:
            # ssid name in first line
            match = re.search(r'^\s*(.+)', p)
            if match:
                ssid_name = match.group(1).strip()
            else:
                ssid_name = "Hidden"
            
            # get all bssids for that ssid
            bssid_chunks = p.split('BSSID')
            for i in range(1, len(bssid_chunks)):
                chunk = bssid_chunks[i]
                
                # mac address
                mac_match = re.search(r'[:\s]+([0-9a-fA-F:]{17})', chunk)
                # signal percentage
                sig_match = re.search(r':\s+(\d+)%', chunk)
                
                if mac_match and sig_match:
                    bssid = mac_match.group(1)
                    quality = int(sig_match.group(1))
                    # convert to dbm
                    rssi = (quality / 2) - 100
                    
                    networks.append({
                        'Timestamp': now,
                        'Room_Label': room_name,
                        'SSID': ssid_name,
                        'BSSID': bssid,
                        'Signal_Quality_Percent': quality,
                        'RSSI_dBm': rssi
                    })
        except:

            continue
            
    return networks


filename = f"wifi_dataset_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

# create empty csv
columns = ['Timestamp', 'Room_Label', 'SSID', 'BSSID', 'Signal_Quality_Percent', 'RSSI_dBm']
empty_df = pd.DataFrame(columns=columns)
empty_df.to_csv(filename, index=False)

print("output file:", filename)
print()

while True:
    room = input("enter room (or exit to quit): ").strip()
    
    if room.lower() == 'exit':
        print("exiting...")
        break
    
    if room == "":
        print("room cant be empty!")
        continue
    
    try:
        duration = int(input("how many seconds? "))
    except:
        print("thats not a number")
        continue
    
    print(f"starting scan for {room}...")
    
    start = time.time()
    scan_num = 0
    
    while (time.time() - start) < duration:
        
        raw = scan_wifi()
        
        if raw == None:
            print("scan failed, retrying...")
            time.sleep(1)
            continue
        
        parsed = parse_it(raw, room)
        
        # append to csv
        if len(parsed) > 0:
            df = pd.DataFrame(parsed)
            df.to_csv(filename, mode='a', header=False, index=False)
        
        scan_num = scan_num + 1
        elapsed = int(time.time() - start)
        
        # show progress
        sys.stdout.write(f"\rscan #{scan_num}, {elapsed}s passed, found {len(parsed)} aps")
        sys.stdout.flush()
        
        # wait 3 sec between scans
        time.sleep(3)
    
    print()
    print(f"finished {room}, total {scan_num} scans")
    print()

print("done!")
