import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, f1_score, classification_report, confusion_matrix

# load data
df = pd.read_csv("wifi_dataset_20251201_190127.csv")
df = df[df["Room_Label"] != "G042"]  # dont need this room as we have 10 already

print("rows:", len(df))
print("rooms:", df["Room_Label"].unique())

bssids = df["BSSID"].unique()
print("bssids:", len(bssids))

# make fingerprint for each scan
data = []
labels = []
for (ts, room), g in df.groupby(["Timestamp", "Room_Label"]):
    row = {b: -100 for b in bssids}  # default -100 if not seen
    for _, r in g.iterrows():
        row[r["BSSID"]] = r["RSSI_dBm"]
    data.append(row)
    labels.append(room)

X = pd.DataFrame(data)
y = labels

print("shape:", X.shape)

# split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# train
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
pred = rf.predict(X_test)

# results
print("\n--- results ---")
print("acc:", accuracy_score(y_test, pred))
print("prec:", precision_score(y_test, pred, average="weighted"))
print("f1:", f1_score(y_test, pred, average="weighted"))
print("\n", classification_report(y_test, pred))
print(confusion_matrix(y_test, pred))
